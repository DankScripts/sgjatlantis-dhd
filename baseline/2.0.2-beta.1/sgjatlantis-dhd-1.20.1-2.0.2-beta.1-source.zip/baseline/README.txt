The frozen 2.0.0-beta.1 uniform-table-background JAR is used as the binary
baseline so every accepted Atlantis DHD behavior and asset remains byte-for-byte
unchanged. Its SHA-256 is:

315f87cda1e2c7b5939a5c7efdf2c5bec363427b6cd0092327e753ab9af9b8fd

Gradle compiles only the 2.0.1 compatibility additions, then overlays them and
the updated metadata onto this baseline when the releaseJar task runs.
