# Atlantis DHD Upgrade 2.0.2-beta.1

This release preserves the complete `2.0.1-beta.1` Forge 1.20.1 Atlantis DHD,
including its narrowly guarded compatibility bridge for
`moregates-4.3.2-forge-1.20.1.jar` (CurseForge file `5783142`).

The physical DHD table shell now uses the same copper, dark-inlay, segmented
fascia, and deck language as the Atlantis City Shield console. The DHD itself,
all triangle buttons, center controls, and the six patterned left-side crystal
panels retain their existing geometry and assignments. The DHD mounting plate
keeps its geometry but uses a UV-safe copper-brown texture from the new table
palette so its small angled pieces do not develop bright texture seams.
The narrow recessed strip behind the five front fascia panels likewise uses a
uniform dark texture so its exposed corner faces remain clean at every mipmap
level.

The bridge detects the exact legacy JAR by filename and SHA-256, then generates
an internal high-priority compatibility pack from the installed More Gates
resources. It migrates old symbol and point-of-origin data, splits the two legacy
symbol atlases for SGJourney's current sprite system, and fills in the modern
wormhole transition fields. More Gates itself is not bundled.

## Configuration

The setting is written to `config/sgjatlantis-dhd.toml`:

```toml
# More Gates 4.3.2 compatibility
# ONLY for moregates-4.3.2-forge-1.20.1.jar (CurseForge file 5783142).
# true (default): enable the legacy More Gates 4.3.2 compatibility bridge.
# false: disable this bridge. Other More Gates versions are never patched.
# Restart Minecraft after changing this setting.
enableMoreGates432CompatibilityPatch = true
```

## Build

Run `./gradlew release`. The finished JAR and source archive are written to
`dist/`.
