# 2.0.2-beta.1

- Restyles only the Atlantis DHD table shell with the shield console's copper,
  dark-inlay, deck, and segmented fascia visual language.
- Adds a recessed front band, five raised fascia blocks, and subtle foot inlays
  without moving the table or altering its two-block footprint.
- Leaves the DHD, DHD plate, triangle buttons, center controls, and six patterned
  left-side crystal panels unchanged.
- Includes the updated Blockbench source and a reproducible model-generation
  script.
- Fixes the SGJ Additions override pack so the restyled table's block-model
  bindings and copper textures load with the geometry instead of displaying
  Minecraft's magenta/black missing-texture fallback.
- Recolors the DHD backplate with the same copper-brown fascia treatment used
  by the restyled table and applies the matching fascia/deck treatment to the
  support dividing the two rows of three patterned control crystals.
- Gives the 21-piece DHD dialer plate a dedicated, fully opaque copper-brown
  texture from the table palette, eliminating bright UV and mipmap bleed along
  its perimeter and internal angled seams.
- Replaces the compressed patterned texture on the narrow front shadow band
  with the same solid dark base color, removing the dotted bleed visible at
  both front corner joints without changing their geometry.
- Replaces the floating square iris control with a low-profile, stepped-round
  button seated on the tabletop and finished in the accepted crystal teal.
- Extends both raised side housings outward by a restrained 0.5 model pixel to
  conceal the end-face texture seam without creating oversized side wings.
- Reverses both Z-shaped leg supports to lean in the same direction as the
  Atlantis city-shield control table without changing their height or floor and
  tabletop contact positions.
- Widens the DHD table's sled feet and diagonal supports to approximately the
  same cross-section as the city-shield control table's legs.
- Preserves the complete 2.0.1-beta.1 More Gates 4.3.2 compatibility bridge and
  its existing configuration toggle.

# 2.0.1-beta.1

- Preserves the complete frozen 2.0.0-beta.1 Atlantis DHD implementation.
- Adds a default-enabled, restart-required More Gates compatibility toggle.
- Restricts the bridge to `moregates-4.3.2-forge-1.20.1.jar`, CurseForge file
  `5783142`, verified by its exact SHA-256 fingerprint.
- Migrates More Gates 4.3.2 symbol and point-of-origin registry files to the
  current SGJourney schema.
- Converts the legacy More Gates symbol atlases at runtime without bundling the
  third-party mod or its assets in this release.
- Adds current SGJourney unstable wormhole, vortex, and disconnect definitions
  to legacy More Gates gate variants while retaining each variant's textures,
  sounds, colors, and model settings.
